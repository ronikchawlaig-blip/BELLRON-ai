# BELLRON AI: website + chat (Netlify only)

Everything runs on one Netlify site: static pages + one serverless function (`netlify/functions/chat.mjs`, served at `/api/chat`).

## Deploy (5 minutes)
1. Netlify > Add new site > Deploy manually (drag this whole folder) or connect it to Git. Keep `netlify.toml` at the root.
2. Site settings > Environment variables, add **`NVIDIA_API_KEY`** (from build.nvidia.com). Redeploy.
3. Open `/chat`. Chat now works as a **guest** (history saved in the visitor's browser). Nothing else is required.

Optional env vars: `NVIDIA_MODEL`, `MAX_TOKENS` (default 2048), `GUEST_HOURLY_LIMIT` (default 15 per IP), `HOURLY_LIMIT` (signed-in users, default 30), `ENABLE_THINKING` (`0` never, `1` always, empty = user toggle), `ALLOWED_ORIGIN`.

Netlify function time limits apply (about 10 s default, up to 26-60 s depending on plan). If long answers get cut off, keep Think off or lower `MAX_TOKENS`.

## Optional: accounts + synced history (Supabase)
1. Supabase > SQL Editor > run `supabase/schema.sql`.
2. Put the project URL and anon key in `js/config.js` (`SUPABASE_URL`, `SUPABASE_ANON_KEY`). Set `GOOGLE_LOGIN:true` only if Google OAuth is configured.
3. Add `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` to Netlify env vars. Add your Netlify domain + `/chat.html` to Supabase Auth redirect URLs.
Never put the NVIDIA key or the service-role key in a browser file.

## What's inside
- `index.html`: landing page (WebGL particle hero in `js/hero-particles.js`, scroll animations, Toolkit section)
- `chat.html` + `js/chat.js` + `css/chat.css`: modes (Chat/Code/Explain/Write), Think toggle, HTML/SVG preview and JS runner, file attach, voice input, edit + resend, regenerate, copy/download code, export as Markdown, chat search/rename, custom instructions, guest mode
- `login.html`, `privacy.html`, `terms.html`

## Before public launch
Add a monitored contact email (`CONTACT_EMAIL` in `index.html`) and review the starter Privacy/Terms pages for your jurisdiction.
