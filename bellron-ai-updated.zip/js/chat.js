(function () {
'use strict';
/* BELLRON AI chat. Works as a guest (history in this browser) and, when Supabase is configured, with accounts + synced history. */
const C = window.BELLRON || {};
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const LS = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } },
  del(k) { try { localStorage.removeItem(k); } catch (e) {} }
};
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2));
const sec = ms => ms == null ? '-' : (ms / 1000).toFixed(1) + ' s';
function toast(t) { const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; document.body.appendChild(d); setTimeout(() => d.remove(), 4500); }

/* ---------- state ---------- */
const box = $('#msgs'), inp = $('#in'), list = $('#list'), ttl = $('#title'), app = $('#app');
let sb = null, session = null, db = null;
let chatId = null, chats = [], msgs = [], ctl = null, cur = null, busy = false, stick = true, raf = 0, atts = [], q = '';
let mode = LS.get('bellron.mode', 'chat'); if (!['chat', 'code', 'explain', 'write'].includes(mode)) mode = 'chat';
let think = !!LS.get('bellron.think', false);
let instructions = LS.get('bellron.instructions', '');

/* ---------- storage: local (guest) and Supabase (signed in) ---------- */
const localDb = {
  async listChats() { return LS.get('bellron.chats', []).sort((a, b) => b.updated_at.localeCompare(a.updated_at)); },
  async createChat(title) { const c = { id: uid(), title, updated_at: new Date().toISOString() }; const a = LS.get('bellron.chats', []); a.unshift(c); LS.set('bellron.chats', a); return c; },
  async renameChat(id, title) { const a = LS.get('bellron.chats', []); const c = a.find(x => x.id === id); if (c) { c.title = title; LS.set('bellron.chats', a); } },
  async touch(id) { const a = LS.get('bellron.chats', []); const c = a.find(x => x.id === id); if (c) { c.updated_at = new Date().toISOString(); LS.set('bellron.chats', a); } },
  async deleteChat(id) { LS.set('bellron.chats', LS.get('bellron.chats', []).filter(x => x.id !== id)); LS.del('bellron.msgs.' + id); },
  async loadMsgs(id) { return LS.get('bellron.msgs.' + id, []); },
  async addMsg(id, m) { const a = LS.get('bellron.msgs.' + id, []); const x = { id: uid(), role: m.role, content: m.content, reasoning: m.reasoning || null, meta: m.meta || null }; a.push(x); if (!LS.set('bellron.msgs.' + id, a)) toast('Browser storage is full or blocked. History may not be saved.'); return x.id; },
  async deleteMsgs(id, ids) { if (!ids.length) return; LS.set('bellron.msgs.' + id, LS.get('bellron.msgs.' + id, []).filter(x => !ids.includes(x.id))); }
};
function supaDb(sb) {
  return {
    async listChats() { const r = await sb.from('chats').select('id,title,updated_at').order('updated_at', { ascending: false }).limit(100); if (r.error) throw r.error; return r.data; },
    async createChat(title) { const r = await sb.from('chats').insert({ title }).select('id,title,updated_at').single(); if (r.error) throw r.error; return r.data; },
    async renameChat(id, title) { await sb.from('chats').update({ title }).eq('id', id); },
    async touch(id) { await sb.from('chats').update({ updated_at: new Date().toISOString() }).eq('id', id); },
    async deleteChat(id) { const r = await sb.from('chats').delete().eq('id', id); if (r.error) throw r.error; },
    async loadMsgs(id) { const r = await sb.from('messages').select('id,role,content,reasoning,meta').eq('chat_id', id).order('created_at'); if (r.error) throw r.error; return r.data; },
    async addMsg(id, m) { const r = await sb.from('messages').insert({ chat_id: id, role: m.role, content: m.content, reasoning: m.reasoning || null, meta: m.meta || {} }).select('id').single(); if (r.error) throw r.error; return r.data.id; },
    async deleteMsgs(id, ids) { if (ids.length) await sb.from('messages').delete().in('id', ids); }
  };
}

/* ---------- markdown (everything is escaped first) ---------- */
function inline(s) {
  const codes = [];
  s = s.replace(/`([^`\n]+)`/g, (_, c) => { codes.push(c); return '\u0000' + (codes.length - 1) + '\u0000'; });
  s = esc(s)
    .replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>')
    .replace(/(^|[\s(])\*([^*\s][^*\n]*?)\*(?=$|[\s).,!?;:])/g, '$1<i>$2</i>')
    .replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  return s.replace(/\u0000(\d+)\u0000/g, (_, i) => '<code>' + esc(codes[+i]) + '</code>');
}
function blocks(t) {
  const L = t.split('\n'); let out = '', i = 0;
  const isTbl = k => /^\s*\|.*\|\s*$/.test(L[k] || '') && /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(L[k + 1] || '');
  while (i < L.length) {
    const l = L[i];
    if (!l.trim()) { i++; continue; }
    let m;
    if ((m = l.match(/^(#{1,4})\s+(.*)$/))) { out += '<h' + m[1].length + '>' + inline(m[2]) + '</h' + m[1].length + '>'; i++; continue; }
    if (/^\s*([-*_])\1{2,}\s*$/.test(l)) { out += '<hr>'; i++; continue; }
    if (isTbl(i)) {
      const cells = r => r.trim().replace(/^\||\|$/g, '').split('|').map(c => inline(c.trim()));
      out += '<table><thead><tr>' + cells(L[i]).map(c => '<th>' + c + '</th>').join('') + '</tr></thead><tbody>'; i += 2;
      while (i < L.length && /^\s*\|.*\|\s*$/.test(L[i])) { out += '<tr>' + cells(L[i]).map(c => '<td>' + c + '</td>').join('') + '</tr>'; i++; }
      out += '</tbody></table>'; continue;
    }
    if (/^\s*>\s?/.test(l)) { const b = []; while (i < L.length && /^\s*>\s?/.test(L[i])) b.push(L[i++].replace(/^\s*>\s?/, '')); out += '<blockquote>' + inline(b.join(' ')) + '</blockquote>'; continue; }
    if (/^\s*[-*+]\s+/.test(l)) { out += '<ul>'; while (i < L.length && /^\s*[-*+]\s+/.test(L[i])) out += '<li>' + inline(L[i++].replace(/^\s*[-*+]\s+/, '')) + '</li>'; out += '</ul>'; continue; }
    if (/^\s*\d+[.)]\s+/.test(l)) { out += '<ol>'; while (i < L.length && /^\s*\d+[.)]\s+/.test(L[i])) out += '<li>' + inline(L[i++].replace(/^\s*\d+[.)]\s+/, '')) + '</li>'; out += '</ol>'; continue; }
    const p = []; while (i < L.length && L[i].trim() && !/^(#{1,4}\s|\s*[-*+]\s+|\s*\d+[.)]\s+|\s*>)/.test(L[i]) && !isTbl(i)) p.push(L[i++]);
    if (!p.length) { p.push(L[i++]); }
    out += '<p>' + p.map(inline).join('<br>') + '</p>';
  }
  return out;
}
const EXT = { javascript: 'js', js: 'js', typescript: 'ts', ts: 'ts', python: 'py', py: 'py', html: 'html', css: 'css', json: 'json', bash: 'sh', sh: 'sh', sql: 'sql', java: 'java', c: 'c', cpp: 'cpp', csharp: 'cs', cs: 'cs', go: 'go', rust: 'rs', php: 'php', ruby: 'rb', yaml: 'yml', yml: 'yml', markdown: 'md', md: 'md', svg: 'svg', jsx: 'jsx', tsx: 'tsx', xml: 'xml' };
function fmt(s) {
  return s.split('```').map((p, i) => {
    if (i % 2 === 0) return blocks(p);
    const nl = p.indexOf('\n'); let lang = '', code = p;
    if (nl >= 0 && /^[\w+#.-]{0,20}$/.test(p.slice(0, nl).trim())) { lang = p.slice(0, nl).trim().toLowerCase(); code = p.slice(nl + 1); }
    code = code.replace(/\n$/, '');
    const web = lang === 'html' || lang === 'svg' || (!lang && /^\s*<(!doctype|html)/i.test(code));
    const js = lang === 'js' || lang === 'javascript';
    return '<div class="cb" data-lang="' + esc(lang) + '"><div class="ch"><span>' + esc(lang || 'code') + '</span><span class="acts">' +
      (web ? '<button type="button" class="lk run" data-a="pv">Preview</button>' : '') + (js ? '<button type="button" class="lk run" data-a="runjs">Run</button>' : '') +
      '<button type="button" class="lk" data-a="dl">Download</button><button type="button" class="lk" data-a="cp">Copy</button></span></div><pre><code>' + esc(code) + '</code></pre></div>';
  }).join('');
}

/* ---------- messages ---------- */
const ATT_RE = /\n\n\[Attached file: ([^\]\n]+)\]\n```[^\n]*\n[\s\S]*?\n```/g;
function addMsg(role) {
  const d = document.createElement('div'); d.className = 'm ' + role;
  d.innerHTML = role === 'assistant'
    ? '<div class="think" hidden><details><summary>Show reasoning</summary><pre></pre></details></div><div class="body"></div><div class="mt"></div>'
    : '<div class="fl" hidden></div><div class="body"></div><div class="ua"><button type="button" class="lk ed-b">Edit</button><button type="button" class="lk cpu">Copy</button></div>';
  box.appendChild(d); return d;
}
function render(el, m, streaming) {
  const body = el.querySelector('.body');
  if (m.role === 'user') {
    const files = []; const text = m.content.replace(ATT_RE, (_, n) => { files.push(n); return ''; });
    body.textContent = text;
    const fl = el.querySelector('.fl'); fl.hidden = !files.length; fl.innerHTML = files.map(f => '<span>' + esc(f) + '</span>').join('');
    return;
  }
  if (m.reasoning) { const th = el.querySelector('.think'); th.hidden = false; th.querySelector('pre').textContent = m.reasoning; if (streaming && !m.content) th.querySelector('details').open = true; }
  el.classList.toggle('streaming', !!streaming && !!m.content);
  body.innerHTML = m.content ? fmt(m.content) : (streaming ? '<span class="dots"><i></i><i></i><i></i></span>' : '');
  const mt = el.querySelector('.mt');
  if (streaming) { mt.innerHTML = ''; if (stick) box.scrollTop = box.scrollHeight; return; }
  const me = m.meta || {}; let h = '';
  if (m.error) h += '<p class="note err">' + esc(m.error) + '</p>';
  else if (me.status === 'incomplete') h += '<p class="note">The response was cut off before it finished.</p>';
  else if (me.server && me.server.finish === 'length') h += '<p class="note">The answer stopped at the length limit.</p>';
  if (me.total_ms != null) h += '<span>First token ' + sec(me.first_any_ms) + (m.reasoning ? ' · Answer starts ' + sec(me.first_content_ms) : '') + ' · Total ' + sec(me.total_ms) + '</span>';
  h += '<span class="ac">' + (m.content ? '<button type="button" class="lk cpm">Copy</button>' : '') + '<button type="button" class="lk rg">' + (m.error ? 'Retry' : 'Regenerate') + '</button></span>';
  mt.innerHTML = h;
  if (stick) box.scrollTop = box.scrollHeight;
}
function schedule(el, m) { if (raf) return; raf = requestAnimationFrame(() => { raf = 0; render(el, m, true); }); }
function setBusy(b) { busy = b; $('#send').hidden = b; $('#stop').hidden = !b; }
function clearMsgs() { box.querySelectorAll('.m').forEach(n => n.remove()); msgs = []; }
function showEmpty(on) { $('#empty').hidden = !on; $('#export').hidden = on; }

/* ---------- streaming ---------- */
async function stream(history, m, el) {
  ctl = new AbortController(); cur = m; setBusy(true);
  const t0 = performance.now(); let any = null, first = null, done = null, errMsg = null;
  try {
    const headers = { 'content-type': 'application/json' };
    if (session) headers.authorization = 'Bearer ' + session.access_token;
    const r = await fetch((C.API_URL || '').replace(/\/+$/, '') + '/api/chat', {
      method: 'POST', headers, signal: ctl.signal,
      body: JSON.stringify({ messages: history.filter(x => x.content).map(x => ({ role: x.role, content: x.content })), mode, think, instructions })
    });
    if (!r.ok || !(r.headers.get('content-type') || '').includes('text/event-stream')) { let j = {}; try { j = await r.json(); } catch (e) {} throw new Error(j.error || (r.status === 404 ? 'Chat service is not deployed yet.' : 'Request failed (' + r.status + ')')); }
    const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '';
    for (;;) {
      const x = await rd.read(); if (x.done) break;
      buf += dec.decode(x.value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const blk = buf.slice(0, i); buf = buf.slice(i + 2);
        for (const line of blk.split('\n')) {
          if (!line.startsWith('data:')) continue;
          let ev; try { ev = JSON.parse(line.slice(5)); } catch (e) { continue; }
          const now = performance.now() - t0;
          if (ev.t === 'r') { if (any == null) any = now; m.reasoning += ev.d; }
          else if (ev.t === 'c') { if (any == null) any = now; if (first == null) first = now; m.content += ev.d; }
          else if (ev.t === 'done') done = ev;
          else if (ev.t === 'err') errMsg = ev.m || 'Something went wrong.';
        }
        schedule(el, m);
      }
    }
  } catch (e) { if (e.name !== 'AbortError') errMsg = (e && e.message) || 'Connection lost.'; }
  const total = performance.now() - t0;
  const status = errMsg ? 'error' : m.stopped ? 'stopped' : (done && !done.incomplete) ? 'complete' : 'incomplete';
  if (errMsg) m.error = errMsg;
  m.meta = { status, first_any_ms: any, first_content_ms: first, total_ms: total, server: done ? { ttft_ms: done.ttft_ms, first_content_ms: done.first_content_ms, total_ms: done.total_ms, finish: done.finish, usage: done.usage || null } : null };
  if (raf) { cancelAnimationFrame(raf); raf = 0; }
  render(el, m, false); setBusy(false); ctl = null; cur = null;
  if (m.content) {
    try { m.id = await db.addMsg(chatId, m); await db.touch(chatId); } catch (e) { toast('Could not save this answer.'); }
    const c = chats.find(c => c.id === chatId); if (c) { c.updated_at = new Date().toISOString(); chats = [c].concat(chats.filter(x => x !== c)); renderList(); }
  }
}
async function answer() {
  const m = { role: 'assistant', content: '', reasoning: '' }; const el = addMsg('assistant'); m.el = el; msgs.push(m);
  render(el, m, true);
  await stream(msgs.slice(0, -1), m, el);
}
function composeText(text) {
  let t = text.trim();
  atts.forEach(a => { t += '\n\n[Attached file: ' + a.name + ']\n```' + (EXT[a.ext] ? a.ext : '') + '\n' + a.text.replace(/```/g, '``​`') + '\n```'; });
  return t;
}
async function send(text, opts) {
  if (busy) return;
  const content = (opts && opts.raw) ? text : composeText(text);
  if (!content.trim()) return;
  showEmpty(false); stick = true;
  if (!chatId) {
    const title = (content.replace(ATT_RE, '').trim() || atts[0] && atts[0].name || 'New chat').replace(/\s+/g, ' ').slice(0, 60);
    try { const c = await db.createChat(title); chatId = c.id; chats.unshift(c); ttl.textContent = c.title; renderList(); }
    catch (e) { toast('Could not start a chat. Please try again.'); showEmpty(true); return; }
  }
  const um = { role: 'user', content }; um.el = addMsg('user'); render(um.el, um, false); msgs.push(um);
  inp.value = ''; inp.style.height = 'auto'; atts = []; renderAtts();
  try { um.id = await db.addMsg(chatId, um); } catch (e) { toast('Message could not be saved to history.'); }
  await answer();
}

/* ---------- chat list ---------- */
function groupLabel(iso) {
  const d = new Date(iso), n = new Date(), day = 864e5;
  const a = new Date(d.getFullYear(), d.getMonth(), d.getDate()), b = new Date(n.getFullYear(), n.getMonth(), n.getDate());
  const diff = Math.round((b - a) / day);
  return diff <= 0 ? 'Today' : diff === 1 ? 'Yesterday' : diff < 8 ? 'Previous 7 days' : 'Older';
}
function renderList() {
  const f = chats.filter(c => !q || c.title.toLowerCase().includes(q));
  let last = '', h = '';
  f.forEach(c => { const g = groupLabel(c.updated_at); if (g !== last) { h += '<div class="gl">' + g + '</div>'; last = g; } h += '<div class="ci' + (c.id === chatId ? ' on' : '') + '" data-id="' + esc(c.id) + '"><button class="ct" type="button">' + esc(c.title) + '</button><button class="cr" type="button" aria-label="Rename chat">Rename</button><button class="cd" type="button" aria-label="Delete chat">Delete</button></div>'; });
  list.innerHTML = h || '<p class="fine" style="padding:8px 10px">' + (q ? 'No matching chats.' : 'No chats yet.') + '</p>';
}
async function open(id) {
  if (busy) return;
  let rows; try { rows = await db.loadMsgs(id); } catch (e) { toast('Could not open this chat.'); return; }
  chatId = id; clearMsgs(); showEmpty(false);
  rows.forEach(x => { const m = { id: x.id, role: x.role, content: x.content, reasoning: x.reasoning || '', meta: x.meta || null }; m.el = addMsg(x.role); msgs.push(m); render(m.el, m, false); });
  const last = msgs[msgs.length - 1];
  if (last && last.role === 'user') { const m = { role: 'assistant', content: '', reasoning: '', error: 'No answer was saved for this message.' }; m.el = addMsg('assistant'); msgs.push(m); render(m.el, m, false); }
  const c = chats.find(c => c.id === id); ttl.textContent = c ? c.title : 'Chat';
  stick = true; box.scrollTop = box.scrollHeight; app.classList.remove('open'); renderList();
}
function newChat() { if (busy) return; chatId = null; clearMsgs(); showEmpty(true); ttl.textContent = 'New chat'; app.classList.remove('open'); closePreview(); renderList(); inp.focus(); }
list.addEventListener('click', async e => {
  const row = e.target.closest('.ci'); if (!row) return; const id = row.dataset.id;
  if (e.target.classList.contains('cd')) {
    if (busy || !confirm('Delete this chat?')) return;
    try { await db.deleteChat(id); } catch (er) { toast('Could not delete the chat.'); return; }
    chats = chats.filter(c => c.id !== id); if (id === chatId) newChat(); else renderList();
  } else if (e.target.classList.contains('cr')) {
    const c = chats.find(c => c.id === id); const t = prompt('Rename chat', c ? c.title : ''); if (t && t.trim() && c) { c.title = t.trim().slice(0, 80); await db.renameChat(id, c.title); if (id === chatId) ttl.textContent = c.title; renderList(); }
  } else open(id);
});
$('#search').addEventListener('input', e => { q = e.target.value.trim().toLowerCase(); renderList(); });

/* ---------- message actions ---------- */
function download(name, text, type) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: type || 'text/plain' })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); }
const copy = (t, btn) => navigator.clipboard.writeText(t).then(() => { if (btn) { const o = btn.textContent; btn.textContent = 'Copied'; setTimeout(() => btn.textContent = o, 1400); } }, () => toast('Copy was blocked by the browser.'));
box.addEventListener('click', async e => {
  const t = e.target; if (!(t instanceof Element)) return;
  const cb = t.closest('.cb');
  if (cb && t.dataset.a) {
    const code = cb.querySelector('code').textContent, lang = cb.dataset.lang;
    if (t.dataset.a === 'cp') copy(code, t);
    else if (t.dataset.a === 'dl') download('bellron-code.' + (EXT[lang] || 'txt'), code);
    else if (t.dataset.a === 'pv') openPreview(code, lang === 'svg' ? 'SVG preview' : 'Preview', lang === 'svg');
    else if (t.dataset.a === 'runjs') runJs(code);
    return;
  }
  const el = t.closest('.m'); if (!el) return;
  const idx = msgs.findIndex(x => x.el === el); const m = msgs[idx];
  if (t.classList.contains('cpm') && m) { copy(m.content, t); return; }
  if (t.classList.contains('cpu') && m) { copy(m.content.replace(ATT_RE, ''), t); return; }
  if (t.classList.contains('rg')) {
    const last = msgs[msgs.length - 1]; if (busy || !last || last.el !== el) return;
    if (last.id) { try { await db.deleteMsgs(chatId, [last.id]); } catch (er) {} }
    msgs.pop(); el.remove(); await answer(); return;
  }
  if (t.classList.contains('ed-b') && m && !busy) startEdit(idx);
});
function startEdit(idx) {
  const m = msgs[idx], el = m.el, text = m.content;
  const files = text.match(ATT_RE) || []; const plain = text.replace(ATT_RE, '');
  el.querySelector('.body').hidden = true; el.querySelector('.ua').hidden = true;
  const w = document.createElement('div'); w.className = 'ed';
  w.innerHTML = '<textarea aria-label="Edit message"></textarea><div class="row2"><button type="button" class="btn">Cancel</button><button type="button" class="btn pri">Save and resend</button></div>';
  w.querySelector('textarea').value = plain.trim(); el.appendChild(w); w.querySelector('textarea').focus();
  const done = () => { w.remove(); el.querySelector('.body').hidden = false; el.querySelector('.ua').hidden = false; };
  w.querySelector('.btn').onclick = done;
  w.querySelector('.pri').onclick = async () => {
    const nt = w.querySelector('textarea').value.trim(); if (!nt) return;
    const removed = msgs.splice(idx); removed.forEach(r => r.el && r.el.remove());
    try { await db.deleteMsgs(chatId, removed.map(r => r.id).filter(Boolean)); } catch (er) {}
    await send(nt + files.join(''), { raw: true });
  };
}
box.addEventListener('scroll', () => { stick = box.scrollHeight - box.scrollTop - box.clientHeight < 80; $('#jump').hidden = stick || !msgs.length; });
$('#jump').onclick = () => { stick = true; box.scrollTop = box.scrollHeight; $('#jump').hidden = true; };

/* ---------- preview panel (Replit-style) ---------- */
const pvp = $('#pvp'), pvf = $('#pvf'); let pvDoc = '';
function openPreview(code, title, isSvg) {
  pvDoc = isSvg ? '<!doctype html><meta charset="utf-8"><body style="margin:0;display:grid;place-items:center;min-height:100vh;background:#fff">' + code + '</body>' : (/<html|<!doctype/i.test(code) ? code : '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' + code);
  $('#pvt').textContent = title || 'Preview'; pvp.hidden = false; pvf.srcdoc = pvDoc;
}
function runJs(code) {
  const safe = code.replace(/<\/script/gi, '<\\/script');
  openPreview('<!doctype html><meta charset="utf-8"><body style="margin:0;background:#0b0910;color:#e9e5f2;font:13px/1.6 ui-monospace,Menlo,monospace"><pre id="o" style="margin:0;padding:14px;white-space:pre-wrap"></pre><script>' +
    'const o=document.getElementById("o");const w=(c,a)=>{o.append(Object.assign(document.createElement("div"),{textContent:a.map(x=>{try{return typeof x==="object"?JSON.stringify(x,null,2):String(x)}catch(e){return String(x)}}).join(" "),style:c?"color:"+c:""}))};' +
    '["log","info","warn","error"].forEach(k=>{const c={warn:"#e6c27a",error:"#ff8b8b"}[k];console[k]=(...a)=>w(c,a)});onerror=(m)=>{w("#ff8b8b",["Error: "+m])};' +
    'try{' + safe + '\n}catch(e){w("#ff8b8b",["Error: "+e.message])}<\/script>', 'Console output');
}
function closePreview() { pvp.hidden = true; pvf.srcdoc = ''; }
$('#pvx').onclick = closePreview; $('#pvr').onclick = () => { pvf.srcdoc = ''; setTimeout(() => pvf.srcdoc = pvDoc, 30); };
$('#pvo').onclick = () => { const w = window.open(URL.createObjectURL(new Blob([pvDoc], { type: 'text/html' })), '_blank', 'noopener'); if (!w) toast('Pop-up was blocked.'); };

/* ---------- composer: modes, think, attachments, voice ---------- */
const PH = { chat: 'Message BELLRON AI', code: 'Describe code or paste a bug', explain: 'What do you want to understand?', write: 'What should I write?' };
const SUG = {
  chat: [['Plan', 'Plan a 7 day study schedule to learn JavaScript from zero.'], ['Debug', 'Why does my React component re-render on every keystroke?'], ['Learn', 'Explain recursion as if I am new to programming.'], ['Draft', 'Write a polite email asking my manager for a day off.']],
  code: [['Script', 'Write a Python script that renames every file in a folder by its date.'], ['Web', 'Build a single file HTML page with a working to-do list and local storage.'], ['SQL', 'Write a SQL query for the top 5 customers by total order value.'], ['Convert', 'Convert this JavaScript function to TypeScript with proper types.']],
  explain: [['Concept', 'Explain how HTTPS works step by step.'], ['Compare', 'What is the difference between SQL and NoSQL? When do I use which?'], ['Error', 'Explain what a null pointer exception is with a small example.'], ['Math', 'Teach me Big O notation with simple examples.']],
  write: [['README', 'Draft a README for my Node.js API.'], ['Email', 'Write a cold email to a startup for a frontend internship.'], ['Post', 'Write a LinkedIn post about launching my first project.'], ['Summary', 'Summarise this text in 5 bullet points: ']]
};
function applyMode() {
  document.querySelectorAll('#modes button').forEach(b => b.classList.toggle('on', b.dataset.m === mode));
  inp.placeholder = PH[mode]; LS.set('bellron.mode', mode);
  $('#chips').innerHTML = SUG[mode].map(s => '<button class="chip" type="button" data-p="' + esc(s[1]) + '"><b>' + s[0].toUpperCase() + '</b>' + esc(s[1]) + '</button>').join('');
}
$('#modes').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { mode = b.dataset.m; applyMode(); inp.focus(); } });
$('#chips').addEventListener('click', e => { const c = e.target.closest('.chip'); if (!c) return; const p = c.dataset.p; if (p.endsWith(': ')) { inp.value = p; inp.focus(); } else send(p); });
function applyThink() { $('#think').setAttribute('aria-pressed', think); LS.set('bellron.think', think); }
$('#think').onclick = () => { think = !think; applyThink(); toast(think ? 'Think is on. Answers may take longer.' : 'Think is off.'); };

function renderAtts() { $('#atts').innerHTML = atts.map((a, i) => '<span class="att">' + esc(a.name) + '<button type="button" data-i="' + i + '" aria-label="Remove ' + esc(a.name) + '">×</button></span>').join(''); }
$('#atts').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { atts.splice(+b.dataset.i, 1); renderAtts(); } });
const MAXF = 150 * 1024, MAXT = 300 * 1024;
async function addFiles(files) {
  for (const f of files) {
    const ext = (f.name.split('.').pop() || '').toLowerCase();
    if (f.type.startsWith('image/') || f.type.startsWith('video/') || f.type.startsWith('audio/') || f.type === 'application/pdf') { toast(f.name + ': images, audio, video and PDF are not supported yet. Attach text or code files.'); continue; }
    if (f.size > MAXF) { toast(f.name + ' is larger than 150 KB.'); continue; }
    if (atts.reduce((s, a) => s + a.text.length, 0) + f.size > MAXT) { toast('Attachments are limited to 300 KB in total.'); break; }
    let text; try { text = await f.text(); } catch (e) { toast('Could not read ' + f.name); continue; }
    if (text.includes('\u0000')) { toast(f.name + ' looks like a binary file.'); continue; }
    atts.push({ name: f.name, ext, text });
  }
  renderAtts();
}
$('#attach').onclick = () => $('#file').click();
$('#file').onchange = e => { addFiles([...e.target.files]); e.target.value = ''; };
const cmp = document.querySelector('.cmp');
['dragenter', 'dragover'].forEach(ev => document.addEventListener(ev, e => { if (e.dataTransfer && [...e.dataTransfer.types].includes('Files')) { e.preventDefault(); cmp.classList.add('drag'); } }));
['dragleave', 'drop'].forEach(ev => document.addEventListener(ev, e => { if (ev === 'drop' || e.target === document.documentElement || !e.relatedTarget) cmp.classList.remove('drag'); }));
document.addEventListener('drop', e => { if (e.dataTransfer && e.dataTransfer.files.length) { e.preventDefault(); addFiles([...e.dataTransfer.files]); } });
inp.addEventListener('paste', e => { const fs = [...(e.clipboardData ? e.clipboardData.files : [])]; if (fs.length) { e.preventDefault(); addFiles(fs); } });

const SR = window.SpeechRecognition || window.webkitSpeechRecognition; let rec = null, base = '';
if (SR) {
  $('#mic').hidden = false;
  $('#mic').onclick = () => {
    if (rec) { rec.stop(); return; }
    rec = new SR(); rec.lang = navigator.language || 'en-US'; rec.interimResults = true; rec.continuous = true; base = inp.value ? inp.value.replace(/\s*$/, ' ') : '';
    rec.onresult = ev => { let s = ''; for (let i = 0; i < ev.results.length; i++) s += ev.results[i][0].transcript; inp.value = base + s; inp.dispatchEvent(new Event('input')); };
    rec.onerror = ev => { if (ev.error === 'not-allowed') toast('Microphone permission was denied.'); };
    rec.onend = () => { rec = null; $('#mic').classList.remove('rec'); $('#mic').textContent = 'Mic'; };
    try { rec.start(); $('#mic').classList.add('rec'); $('#mic').textContent = 'Stop'; } catch (e) { rec = null; }
  };
}
$('#form').addEventListener('submit', e => { e.preventDefault(); if (rec) rec.stop(); send(inp.value); });
inp.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); if (rec) rec.stop(); send(inp.value); } });
inp.addEventListener('input', () => { inp.style.height = 'auto'; inp.style.height = Math.min(inp.scrollHeight, 180) + 'px'; });
$('#stop').onclick = () => { if (cur) cur.stopped = true; if (ctl) ctl.abort(); };
$('#new').onclick = newChat;
$('#menu').onclick = () => app.classList.add('open'); $('#close').onclick = $('#ov').onclick = () => app.classList.remove('open');

/* export */
$('#export').onclick = () => {
  const md = '# ' + ttl.textContent + '\n\n' + msgs.filter(m => m.content).map(m => '## ' + (m.role === 'user' ? 'You' : 'BELLRON AI') + '\n\n' + m.content).join('\n\n---\n\n') + '\n';
  download((ttl.textContent.replace(/[^\w-]+/g, '-').slice(0, 40) || 'chat') + '.md', md, 'text/markdown');
};
/* settings */
const dlg = $('#dlg');
$('#settings').onclick = () => { $('#ci').value = instructions; app.classList.remove('open'); dlg.showModal ? dlg.showModal() : dlg.setAttribute('open', ''); };
$('#saveset').onclick = () => { instructions = $('#ci').value.slice(0, 1000); LS.set('bellron.instructions', instructions); toast(instructions ? 'Custom instructions saved.' : 'Custom instructions cleared.'); };
$('#clear').onclick = () => { if (!confirm('Delete all chats stored in this browser?')) return; LS.get('bellron.chats', []).forEach(c => LS.del('bellron.msgs.' + c.id)); LS.del('bellron.chats'); dlg.close(); if (!session) { chats = []; newChat(); } toast('Local chats deleted.'); };
/* shortcuts */
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); newChat(); }
  else if (e.key === 'Escape') { if (busy) $('#stop').click(); else if (!pvp.hidden) closePreview(); else app.classList.remove('open'); }
  else if (e.key === '/' && !/INPUT|TEXTAREA/.test((document.activeElement || {}).tagName || '') && !dlg.open) { e.preventDefault(); inp.focus(); }
});

/* ---------- boot ---------- */
function loadScript(src) { return new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); }); }
(async () => {
  applyMode(); applyThink();
  const accounts = !!(C.SUPABASE_URL && C.SUPABASE_ANON_KEY);
  if (accounts) {
    try {
      await Promise.race([loadScript('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js'), new Promise((_, r) => setTimeout(r, 8000))]);
      sb = window.supabase.createClient(C.SUPABASE_URL, C.SUPABASE_ANON_KEY);
      const r = await sb.auth.getSession(); session = r.data && r.data.session;
    } catch (e) { sb = null; session = null; }
  }
  if (sb && session) {
    db = supaDb(sb);
    $('#who').textContent = session.user.email || ''; $('#out').hidden = false;
    sb.auth.onAuthStateChange((ev, s) => { if (!s) location.replace('chat.html'); else session = s; });
    $('#out').onclick = async () => { await sb.auth.signOut(); location.replace('chat.html'); };
  } else {
    db = localDb;
    $('#who').textContent = 'Guest. Chats are saved in this browser.';
    if (sb || accounts) $('#signin').hidden = false;
  }
  try { chats = await db.listChats(); } catch (e) { toast('Could not load your chats.'); chats = []; }
  renderList(); showEmpty(true); app.hidden = false; inp.focus();
})();
})();
