/* Public values only. The Supabase anon key is meant to be public (row-level security protects the data).
   Leave SUPABASE_* empty to run BELLRON AI in guest mode (chats saved in the visitor's browser, no sign-in).
   API_URL stays empty: the chat endpoint is a Netlify Function served at /api/chat on the same site.
   NEVER put the NVIDIA key or the Supabase service_role key in this file. */
window.BELLRON={
  SUPABASE_URL:'',
  SUPABASE_ANON_KEY:'',
  API_URL:'',
  GOOGLE_LOGIN:false
};
