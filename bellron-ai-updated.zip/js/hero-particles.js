/* BELLRON AI hero: GPU particle cloud shaped like a twisted hollow ring ("bell"),
   stirred by the cursor/touch. Raw WebGL, no dependencies. Fails silently if WebGL is missing. */
(function () {
  'use strict';
  var cv = document.getElementById('heroGL');
  if (!cv) return;
  var RM = matchMedia('(prefers-reduced-motion:reduce)').matches;
  var mob = matchMedia('(max-width:760px)').matches;
  var gl = cv.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: false }) || cv.getContext('experimental-webgl');
  if (!gl) { document.documentElement.classList.add('no-gl'); return; }

  var N = window.__HERO_N || (mob ? 16000 : 80000), TRAIL = 20;
  var VS = [
    'precision highp float;',
    'attribute vec3 a_pos; attribute vec4 a_rnd;',
    'uniform mat4 u_mvp; uniform float u_time, u_dpr, u_scale, u_aspect;',
    'uniform vec4 u_trail[' + TRAIL + '];',
    'varying vec4 v_rnd; varying float v_glow;',
    'void main(){',
    '  vec3 p = a_pos;',
    '  float t = u_time;',
    '  p += 0.035 * vec3(sin(t*.7 + a_rnd.x*40.), cos(t*.6 + a_rnd.y*40.), sin(t*.5 + a_rnd.z*40.));',
    '  p *= 1.0 + 0.045 * sin(t*.8 + p.x*3.0 + p.y*2.0);',
    '  vec4 c = u_mvp * vec4(p, 1.0);',
    '  vec2 ndc = c.xy / c.w;',
    '  vec2 d = vec2(0.0); float glow = 0.0;',
    '  for (int i = 0; i < ' + TRAIL + '; i++) {',
    '    vec4 tr = u_trail[i];',
    '    vec2 q = (ndc - tr.xy) * vec2(u_aspect, 1.0);',
    '    float r2 = dot(q, q);',
    '    float k = exp(-r2 * 9.0);',
    '    vec2 sw = vec2(-q.y, q.x);',
    '    d += (tr.zw * k * 1.6) + normalize(q + 1e-4) * k * length(tr.zw) * 0.9 + sw * k * length(tr.zw) * 1.3;',
    '    glow += k * length(tr.zw) * 6.0;',
    '  }',
    '  d.x /= u_aspect;',
    '  ndc += d * (0.6 + a_rnd.w * 0.8);',
    '  gl_Position = vec4(ndc * c.w, c.z, c.w);',
    '  float sz = mix(1.0, 2.6, pow(a_rnd.y, 12.0)) * mix(0.6, 1.0, a_rnd.z);',
    '  gl_PointSize = clamp(sz * u_dpr * u_scale / c.w * 1.25, 1.5, 9.0 * u_dpr);',
    '  v_rnd = a_rnd; v_glow = clamp(glow, 0.0, 1.5);',
    '}'
  ].join('\n');
  var FS = [
    'precision highp float;',
    'varying vec4 v_rnd; varying float v_glow; uniform float u_time;',
    'void main(){',
    '  vec2 q = gl_PointCoord - .5; float r = length(q); if (r > .5) discard;',
    '  float soft = smoothstep(.5, .05, r);',
    '  vec3 base = vec3(mix(.55, 1.0, v_rnd.x));',
    '  vec3 orange = vec3(1.0, .48, .24), violet = vec3(.65, .55, 1.0);',
    '  float po = pow(v_rnd.z, 9.0), pv = pow(v_rnd.x, 10.0);',
    '  vec3 col = mix(base, orange, clamp(po * 2.2, 0., 1.));',
    '  col = mix(col, violet, clamp(pv * 2.0, 0., 1.));',
    '  float spark = .6 + .4 * sin(u_time * 3.0 + v_rnd.y * 30.0) * step(.82, v_rnd.z);',
    '  col += vec3(1.0, .6, .35) * v_glow * .5;',
    '  float a = soft * (.9 + .6 * v_rnd.y) * spark;',
    '  gl_FragColor = vec4(col * a, a);',
    '}'
  ].join('\n');

  function sh(type, src) { var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) { console.warn(gl.getShaderInfoLog(s)); return null; } return s; }
  var vs = sh(gl.VERTEX_SHADER, VS), fs = sh(gl.FRAGMENT_SHADER, FS);
  if (!vs || !fs) { document.documentElement.classList.add('no-gl'); return; }
  var prog = gl.createProgram(); gl.attachShader(prog, vs); gl.attachShader(prog, fs); gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) { console.warn(gl.getProgramInfoLog(prog)); document.documentElement.classList.add('no-gl'); return; }
  gl.useProgram(prog);

  /* geometry: points on a twisted hollow ring with lobes */
  var pos = new Float32Array(N * 3), rnd = new Float32Array(N * 4);
  for (var i = 0; i < N; i++) {
    var u = Math.random() * Math.PI * 2, v = Math.random() * Math.PI * 2;
    var R = 1 + 0.16 * Math.sin(2 * u + .6);
    var r = 0.30 * (1 + 0.38 * Math.sin(3 * u + 1.2)) * (0.92 + Math.random() * 0.16);
    var tw = v + 1.5 * u;
    var nx = Math.cos(u), ny = Math.sin(u);
    var rad = R + r * Math.cos(tw);
    pos[i * 3] = nx * rad;
    pos[i * 3 + 1] = ny * rad * 0.94;
    pos[i * 3 + 2] = r * Math.sin(tw) * 1.15 + 0.32 * Math.sin(2 * u);
    rnd[i * 4] = Math.random(); rnd[i * 4 + 1] = Math.random(); rnd[i * 4 + 2] = Math.random(); rnd[i * 4 + 3] = Math.random();
  }
  function buf(data, name, size) {
    var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    var l = gl.getAttribLocation(prog, name); gl.enableVertexAttribArray(l); gl.vertexAttribPointer(l, size, gl.FLOAT, false, 0, 0);
  }
  buf(pos, 'a_pos', 3); buf(rnd, 'a_rnd', 4);
  var U = {}; ['u_mvp', 'u_time', 'u_dpr', 'u_scale', 'u_aspect', 'u_trail'].forEach(function (n) { U[n] = gl.getUniformLocation(prog, n); });
  gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE); gl.clearColor(0, 0, 0, 0);

  /* tiny matrix helpers (column-major) */
  function mul(a, b) { var o = new Float32Array(16); for (var c = 0; c < 4; c++) for (var r = 0; r < 4; r++) { var s = 0; for (var k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; }
  function persp(f, a, n, fa) { var t = 1 / Math.tan(f / 2), o = new Float32Array(16); o[0] = t / a; o[5] = t; o[10] = (fa + n) / (n - fa); o[11] = -1; o[14] = 2 * fa * n / (n - fa); return o; }
  function rotY(a) { var c = Math.cos(a), s = Math.sin(a); return new Float32Array([c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]); }
  function rotX(a) { var c = Math.cos(a), s = Math.sin(a); return new Float32Array([1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]); }
  function rotZ(a) { var c = Math.cos(a), s = Math.sin(a); return new Float32Array([c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]); }
  function trans(x, y, z) { return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1]); }

  var W = 0, H = 0, dpr = Math.min(window.devicePixelRatio || 1, 2);
  function resize() {
    W = innerWidth; H = innerHeight; dpr = Math.min(window.devicePixelRatio || 1, mob ? 1.5 : 2);
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); gl.viewport(0, 0, cv.width, cv.height);
  }
  resize(); addEventListener('resize', resize);

  /* cursor trail: ring buffer of (x, y, vx, vy) in NDC; velocity decays => cloud heals */
  var trail = [], head = 0;
  for (var k = 0; k < TRAIL; k++) trail.push({ x: 9, y: 9, vx: 0, vy: 0 });
  var gx = 0, gy = 0, px = null, py = null, lastMove = 0, active = true;
  function pointer(cx, cy) {
    var x = cx / W * 2 - 1, y = -(cy / H * 2 - 1);
    gx += ((x) - gx) * 0.5; gy += ((y) - gy) * 0.5;
    if (px !== null) {
      var vx = (x - px), vy = (y - py), sp = Math.hypot(vx * W / H, vy);
      if (sp > 0.0004) {
        var m = Math.min(1, 0.9 / Math.max(sp, 0.03)); /* cap velocity */
        head = (head + 1) % TRAIL; var s = trail[head]; s.x = x; s.y = y; s.vx = vx * Math.min(m, 1) * 0.9; s.vy = vy * Math.min(m, 1) * 0.9;
      }
    }
    px = x; py = y; lastMove = performance.now();
  }
  addEventListener('pointermove', function (e) { pointer(e.clientX, e.clientY); }, { passive: true });
  addEventListener('touchmove', function (e) { var t = e.touches[0]; if (t) pointer(t.clientX, t.clientY); }, { passive: true });
  addEventListener('pointerleave', function () { px = null; });
  document.addEventListener('visibilitychange', function () { active = !document.hidden; if (active && !RM) requestAnimationFrame(frame); });

  var tbuf = new Float32Array(TRAIL * 4), t0 = performance.now(), rotA = 0.4, gazeX = 0, gazeY = 0, running = false;
  function frame(now) {
    if (!active) return;
    var vis = scrollY < innerHeight * 1.25;
    if (!vis) { running = false; requestAnimationFrame(frame); return; }
    var t = (now - t0) / 1000;
    for (var i = 0; i < TRAIL; i++) { var s = trail[i]; s.vx *= 0.955; s.vy *= 0.955; tbuf[i * 4] = s.x; tbuf[i * 4 + 1] = s.y; tbuf[i * 4 + 2] = s.vx; tbuf[i * 4 + 3] = s.vy; }
    gazeX += (gx - gazeX) * 0.05; gazeY += (gy - gazeY) * 0.05;
    var a = W / H, sc = mob ? 0.62 : 1;
    var proj = persp(0.52, a, 0.1, 50);
    var model = mul(rotZ(0.25 + gazeX * 0.08), mul(rotX(-0.55 + gazeY * -0.18), rotY(rotA + t * 0.12 + gazeX * 0.35)));
    var view = trans(mob ? 0 : (a > 1.2 ? 1.7 : 0.6), mob ? 1.1 : 0.15, mob ? -12 : -11.5);
    var mvp = mul(proj, mul(view, model));
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniformMatrix4fv(U.u_mvp, false, mvp);
    gl.uniform1f(U.u_time, t); gl.uniform1f(U.u_dpr, dpr); gl.uniform1f(U.u_aspect, a);
    gl.uniform1f(U.u_scale, mob ? 11 : 15 * Math.min(1.3, H / 800));
    gl.uniform4fv(U.u_trail, tbuf);
    gl.drawArrays(gl.POINTS, 0, N);
    if (!RM) requestAnimationFrame(frame);
  }
  cv.classList.add('ready');
  requestAnimationFrame(frame);
  if (RM) addEventListener('resize', function () { requestAnimationFrame(frame); });
})();
