/* BELLRON AI chat endpoint (Netlify Function, streaming). Served at /api/chat.
   Required env var:  NVIDIA_API_KEY
   Optional (enables accounts + per-user limits): SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY
   Optional: NVIDIA_MODEL, NVIDIA_BASE_URL, MAX_TOKENS, HOURLY_LIMIT, GUEST_HOURLY_LIMIT,
             ENABLE_THINKING (0 = never, 1 = always, empty = user toggle), ALLOWED_ORIGIN, OVERALL_TIMEOUT_MS, IDLE_TIMEOUT_MS */
const E = process.env;
const BASE = (E.NVIDIA_BASE_URL || 'https://integrate.api.nvidia.com/v1').replace(/\/$/, '');
const MODEL = E.NVIDIA_MODEL || 'nvidia/nemotron-3-ultra-550b-a55b';
const MAX_TOKENS = parseInt(E.MAX_TOKENS, 10) || 2048;
const LIMIT = parseInt(E.HOURLY_LIMIT, 10) || 30;
const GUEST_LIMIT = parseInt(E.GUEST_HOURLY_LIMIT, 10) || 15;
const OVERALL = parseInt(E.OVERALL_TIMEOUT_MS, 10) || 50000;
const IDLE = parseInt(E.IDLE_TIMEOUT_MS, 10) || 30000;
const MAX_MSGS = 20, MAX_CHARS = 60000;
const ACCOUNTS = !!(E.SUPABASE_URL && E.SUPABASE_ANON_KEY && E.SUPABASE_SERVICE_ROLE_KEY);

const SYSTEM = `You are BELLRON AI, an assistant for coding, explanations, writing and analysis.
Reply in the language the user writes in. Be accurate and direct. Put code in fenced code blocks that name the language. If you are unsure, say so instead of guessing.
If asked who made you or which model you run on, say you are BELLRON AI and that it runs on a large language model from NVIDIA (Nemotron). Never claim BELLRON trained it and never claim to be human.`;

const MODES = {
  chat: '',
  code: 'Mode: Code. Prefer complete, runnable code in fenced blocks that name the language. Keep prose short. For web pages, return one self-contained HTML file in a single html block.',
  explain: 'Mode: Explain. Teach step by step in simple words with small examples or analogies. Check the basics first, then go deeper.',
  write: 'Mode: Write. Produce polished, ready-to-use writing in the requested tone and format. Do not ask unnecessary questions.'
};
const json = (code, o, extra = {}) => new Response(JSON.stringify(o), {
  status: code,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', ...extra }
});

/* ---- limits ---- */
async function getUser(token) {
  const r = await fetch(E.SUPABASE_URL + '/auth/v1/user', { headers: { apikey: E.SUPABASE_ANON_KEY, authorization: 'Bearer ' + token } });
  if (!r.ok) return null;
  const u = await r.json();
  return u && u.id ? u : null;
}
async function allowUser(uid) {
  const h = { apikey: E.SUPABASE_SERVICE_ROLE_KEY, authorization: 'Bearer ' + E.SUPABASE_SERVICE_ROLE_KEY };
  const since = encodeURIComponent(new Date(Date.now() - 3600e3).toISOString());
  const r = await fetch(`${E.SUPABASE_URL}/rest/v1/usage?select=id&user_id=eq.${encodeURIComponent(uid)}&created_at=gte.${since}`, { method: 'HEAD', headers: { ...h, prefer: 'count=exact' } });
  let n = parseInt((r.headers.get('content-range') || '').split('/')[1], 10);
  if (r.status === 416) n = 0;
  if (Number.isNaN(n) || (!r.ok && r.status !== 416)) throw new Error('usage check failed (' + r.status + ')');
  if (n >= LIMIT) return false;
  const w = await fetch(E.SUPABASE_URL + '/rest/v1/usage', { method: 'POST', headers: { ...h, 'content-type': 'application/json', prefer: 'return=minimal' }, body: JSON.stringify({ user_id: uid }) });
  if (!w.ok) throw new Error('usage write failed (' + w.status + ')');
  return true;
}
/* Guests: best-effort per-IP limit kept in memory (resets when the function instance recycles). */
const hits = new Map();
function allowGuest(ip) {
  const now = Date.now(), arr = (hits.get(ip) || []).filter(t => now - t < 3600e3);
  if (arr.length >= GUEST_LIMIT) { hits.set(ip, arr); return false; }
  arr.push(now); hits.set(ip, arr);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.some(t => now - t < 3600e3)) hits.delete(k);
  return true;
}

/* Separates <think>...</think> that some deployments put inside the answer text. */
function splitter(emit) {
  let mode = 'detect', buf = '';
  return {
    push(s) {
      buf += s;
      for (;;) {
        if (mode === 'detect') {
          const t = buf.replace(/^\s+/, '');
          if (t.length < 7 && '<think>'.startsWith(t)) return;
          if (t.startsWith('<think>')) { buf = t.slice(7); mode = 'think'; continue; }
          mode = 'answer'; continue;
        }
        if (mode === 'think') {
          const i = buf.indexOf('</think>');
          if (i >= 0) { if (i > 0) emit('r', buf.slice(0, i)); buf = buf.slice(i + 8).replace(/^\s+/, ''); mode = 'answer'; continue; }
          if (buf.length > 7) { emit('r', buf.slice(0, buf.length - 7)); buf = buf.slice(-7); }
          return;
        }
        if (buf) { emit('c', buf); buf = ''; }
        return;
      }
    },
    end() { if (buf) { emit(mode === 'think' ? 'r' : 'c', buf); buf = ''; } }
  };
}

export default async (req, context) => {
  const origin = req.headers.get('origin') || '';
  const cors = {};
  if (E.ALLOWED_ORIGIN) {
    if (origin && origin !== E.ALLOWED_ORIGIN && origin !== new URL(req.url).origin) return json(403, { error: 'Origin not allowed.' });
    if (origin === E.ALLOWED_ORIGIN) {
      Object.assign(cors, { 'access-control-allow-origin': origin, 'access-control-allow-methods': 'POST, OPTIONS', 'access-control-allow-headers': 'authorization, content-type', vary: 'Origin' });
    }
  }
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  if (req.method !== 'POST') return json(405, { error: 'Method not allowed.' }, cors);
  if (!E.NVIDIA_API_KEY) { console.error('Missing env var: NVIDIA_API_KEY'); return json(500, { error: 'The service is not configured yet.' }, cors); }

  /* who is calling */
  let uid = null;
  if (ACCOUNTS) {
    const token = (req.headers.get('authorization') || '').replace(/^Bearer\s+/i, '');
    if (token) {
      let user; try { user = await getUser(token); } catch (e) { return json(502, { error: 'Could not verify your session. Try again.' }, cors); }
      if (!user) return json(401, { error: 'Your session expired. Please sign in again.' }, cors);
      uid = user.id;
    }
  }

  let body; try { body = await req.json(); } catch (e) { body = null; }
  let msgs = body && Array.isArray(body.messages) ? body.messages : null;
  if (!msgs || !msgs.length) return json(400, { error: 'No messages.' }, cors);
  msgs = msgs.filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.trim()).map(m => ({ role: m.role, content: m.content })).slice(-MAX_MSGS);
  while (msgs.length > 1 && msgs.reduce((a, m) => a + m.content.length, 0) > MAX_CHARS) msgs.shift();
  if (!msgs.length || msgs[msgs.length - 1].role !== 'user') return json(400, { error: 'The last message must come from the user.' }, cors);
  if (msgs[0].content.length > MAX_CHARS) return json(413, { error: 'That message is too long.' }, cors);

  try {
    if (uid) { if (!(await allowUser(uid))) return json(429, { error: 'You have reached the hourly message limit. Please try again later.' }, cors); }
    else if (!allowGuest((context && context.ip) || req.headers.get('x-nf-client-connection-ip') || 'unknown')) return json(429, { error: 'Guest message limit reached for this hour. Please try again later.' }, cors);
  } catch (e) { console.error(e.message); return json(502, { error: 'Could not check usage limits. Try again.' }, cors); }

  const mode = body && typeof body.mode === 'string' && body.mode in MODES ? body.mode : 'chat';
  const instr = body && typeof body.instructions === 'string' ? body.instructions.replace(/\s+/g, ' ').trim().slice(0, 1000) : '';
  const system = SYSTEM + (MODES[mode] ? '\n' + MODES[mode] : '') + (instr ? '\nThe user set these custom instructions. Follow them unless they conflict with the rules above:\n' + instr : '');
  const wantThink = !!(body && body.think === true) && E.ENABLE_THINKING !== '0';
  const payload = { model: MODEL, messages: [{ role: 'system', content: system }, ...msgs], stream: true, max_tokens: MAX_TOKENS, temperature: 0.7, top_p: 0.95 };
  /* Thinking is OFF by default (fast first token). Users can switch on "Think" in the UI; set ENABLE_THINKING=0 to forbid it, =1 to force it. */
  payload.chat_template_kwargs = { enable_thinking: wantThink || E.ENABLE_THINKING === '1' };

  const ac = new AbortController();
  let why = '';
  const stop = r => { if (!why) { why = r; ac.abort(); } };
  req.signal && req.signal.addEventListener('abort', () => stop('client'));
  const overall = setTimeout(() => stop('timeout'), OVERALL);
  let idle = setTimeout(() => stop('idle'), IDLE);
  const bump = () => { clearTimeout(idle); idle = setTimeout(() => stop('idle'), IDLE); };
  const t0 = Date.now();

  let up;
  try {
    up = await fetch(BASE + '/chat/completions', { method: 'POST', signal: ac.signal, headers: { 'content-type': 'application/json', accept: 'text/event-stream', authorization: 'Bearer ' + E.NVIDIA_API_KEY }, body: JSON.stringify(payload) });
  } catch (e) {
    clearTimeout(overall); clearTimeout(idle);
    console.error('upstream connect error:', why || e.name);
    return json(504, { error: why ? 'The model took too long to respond. Please try again.' : 'Could not reach the model service. Please try again.' }, cors);
  }
  if (!up.ok) {
    clearTimeout(overall); clearTimeout(idle);
    let snip = ''; try { snip = (await up.text()).slice(0, 300).replace(/nvapi-[\w-]+/g, '[redacted]'); } catch (e) {}
    console.error('upstream status', up.status, snip);
    const m = up.status === 429 ? 'The model is busy right now. Please try again in a moment.' : (up.status === 401 || up.status === 403) ? 'The service is temporarily unavailable.' : up.status === 400 ? 'The model could not process that request.' : 'The model service had a problem. Please try again.';
    return json(up.status === 429 ? 429 : 502, { error: m }, cors);
  }

  const enc = new TextEncoder(), dec = new TextDecoder();
  const stream = new ReadableStream({
    async start(ctrl) {
      let closed = false;
      const send = o => { if (!closed) { try { ctrl.enqueue(enc.encode('data: ' + JSON.stringify(o) + '\n\n')); } catch (e) { closed = true; } } };
      const end = () => { if (!closed) { closed = true; try { ctrl.close(); } catch (e) {} } };
      ctrl.enqueue(enc.encode(': ok\n\n'));
      let tAny = null, tContent = null, finish = null, usage = null, sawDone = false, buf = '';
      const emit = (t, d) => { if (!d) return; const n = Date.now() - t0; if (tAny == null) tAny = n; if (t === 'c' && tContent == null) tContent = n; send({ t, d }); };
      const sp = splitter(emit);
      const line = l => {
        if (!l.startsWith('data:')) return;
        const s = l.slice(5).trim();
        if (s === '[DONE]') { sawDone = true; return; }
        let j; try { j = JSON.parse(s); } catch (e) { return; }
        if (j.usage) usage = j.usage;
        const ch = j.choices && j.choices[0]; if (!ch) return;
        if (ch.finish_reason) finish = ch.finish_reason;
        const d = ch.delta || {};
        const r = d.reasoning_content != null ? d.reasoning_content : d.reasoning;
        if (typeof r === 'string' && r) emit('r', r);
        if (typeof d.content === 'string' && d.content) sp.push(d.content);
      };
      let failed = null;
      try {
        const rd = up.body.getReader();
        for (;;) {
          const x = await rd.read();
          if (x.done) break;
          bump(); buf += dec.decode(x.value, { stream: true });
          let i; while ((i = buf.indexOf('\n')) >= 0) { line(buf.slice(0, i).replace(/\r$/, '')); buf = buf.slice(i + 1); }
        }
        if (buf) line(buf.replace(/\r$/, ''));
        sp.end();
      } catch (e) { failed = e; }
      clearTimeout(overall); clearTimeout(idle);
      if (why === 'client') return end();
      if (failed || why) {
        sp.end();
        console.error('stream ended early:', why || (failed && failed.name));
        send({ t: 'err', m: why ? 'The model took too long. The answer above may be incomplete.' : 'The connection to the model was interrupted.' });
        return end();
      }
      send({ t: 'done', finish, usage, ttft_ms: tAny, first_content_ms: tContent, total_ms: Date.now() - t0, incomplete: !(sawDone || finish) });
      end();
    },
    cancel() { stop('client'); }
  });
  return new Response(stream, { status: 200, headers: { 'content-type': 'text/event-stream; charset=utf-8', 'cache-control': 'no-cache, no-transform', 'x-accel-buffering': 'no', 'x-content-type-options': 'nosniff', ...cors } });
};

export const config = { path: '/api/chat' };
