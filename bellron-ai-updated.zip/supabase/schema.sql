-- Run this once in Supabase: SQL Editor > New query > paste > Run.
create table if not exists public.chats(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title text not null default 'New chat',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.messages(
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references public.chats(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null,
  reasoning text,
  meta jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create table if not exists public.usage(
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create index if not exists chats_user_updated on public.chats(user_id, updated_at desc);
create index if not exists messages_chat_created on public.messages(chat_id, created_at);
create index if not exists usage_user_created on public.usage(user_id, created_at desc);

alter table public.chats enable row level security;
alter table public.messages enable row level security;
alter table public.usage enable row level security;  -- no policies: only the server (service role) can touch it

drop policy if exists chats_own on public.chats;
create policy chats_own on public.chats for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists messages_own on public.messages;
create policy messages_own on public.messages for all to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid() and exists(select 1 from public.chats c where c.id = chat_id and c.user_id = auth.uid()));
